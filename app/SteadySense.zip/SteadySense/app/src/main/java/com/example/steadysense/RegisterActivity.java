package com.example.steadysense;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.example.steadysense.models.User;

public class RegisterActivity extends BaseActivity {

    private TextInputEditText nameEditText, emailEditText, passwordEditText, ageEditText, caretakerIdEditText;
    private TextInputLayout ageLayout, caretakerIdLayout;
    private RadioGroup roleGroup;
    private MaterialButton registerButton;
    private TextView loginText;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.regEmailEditText);
        passwordEditText = findViewById(R.id.regPasswordEditText);
        ageEditText = findViewById(R.id.ageEditText);
        caretakerIdEditText = findViewById(R.id.caretakerIdEditText);
        ageLayout = findViewById(R.id.ageLayout);
        caretakerIdLayout = findViewById(R.id.caretakerIdLayout);
        roleGroup = findViewById(R.id.roleGroup);
        registerButton = findViewById(R.id.registerButton);
        loginText = findViewById(R.id.loginText);
        progressBar = findViewById(R.id.regProgressBar);

        roleGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioElder) {
                ageLayout.setVisibility(View.VISIBLE);
                caretakerIdLayout.setVisibility(View.VISIBLE);
            } else {
                ageLayout.setVisibility(View.GONE);
                caretakerIdLayout.setVisibility(View.GONE);
            }
        });

        registerButton.setOnClickListener(v -> registerUser());
        loginText.setOnClickListener(v -> finish());
    }

    private void registerUser() {
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim().toLowerCase();
        String password = passwordEditText.getText().toString().trim();
        int selectedRoleId = roleGroup.getCheckedRadioButtonId();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || selectedRoleId == -1) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String role = (selectedRoleId == R.id.radioElder) ? "Elder" : "Caretaker";
        
        if ("Elder".equals(role)) {
            String ageStr = ageEditText.getText().toString();
            if (ageStr.isEmpty()) {
                Toast.makeText(this, "Please enter elder's age", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        saveUserToFirestore(name, email, role);
                    } else {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(this, "Registration Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void saveUserToFirestore(String name, String email, String role) {
        if (mAuth.getCurrentUser() == null) {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Authentication failed. Please try again.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String uid = mAuth.getCurrentUser().getUid();
        User user = new User(uid, name, email, role);

        if ("Elder".equals(role)) {
            String ageStr = ageEditText.getText().toString().trim();
            if (!ageStr.isEmpty()) {
                try {
                    user.setAge(Integer.parseInt(ageStr));
                } catch (NumberFormatException e) {
                    user.setAge(0);
                }
            }
            String rawCId = caretakerIdEditText.getText().toString().trim();
            String resolvedCId = rawCId.replace("#", "").toUpperCase();
            user.setCaretakerId(resolvedCId);
            
            java.util.List<String> cIds = new java.util.ArrayList<>();
            if (!resolvedCId.isEmpty()) {
                cIds.add(resolvedCId);
            }
            user.setCaretakerIds(cIds);
        }

        db.collection("users").document(uid).set(user)
                .addOnSuccessListener(aVoid -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Registration Successful and Saved to Firestore", Toast.LENGTH_SHORT).show();
                    if ("Elder".equals(role)) {
                        startActivity(new Intent(RegisterActivity.this, ElderActivity.class));
                    } else {
                        startActivity(new Intent(RegisterActivity.this, CaretakerActivity.class));
                    }
                    finish();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Firestore Error: " + e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    // Log the error for debugging
                    android.util.Log.e("RegisterActivity", "Firestore Error", e);
                });
    }
}
