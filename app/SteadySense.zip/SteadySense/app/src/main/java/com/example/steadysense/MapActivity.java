package com.example.steadysense;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MapActivity extends BaseActivity {

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        webView = findViewById(R.id.mapWebView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());

        // Javascript interface to allow closing the activity from the HTML
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void closeMap() {
                runOnUiThread(() -> finish());
            }
        }, "AndroidApp");

        // Parse coordinates from intent
        double elderLat = getIntent().getDoubleExtra("elderLat", 0.0);
        double elderLng = getIntent().getDoubleExtra("elderLng", 0.0);
        String elderName = getIntent().getStringExtra("elderName");
        if (elderName == null) elderName = "Elder Location";

        // Load asset with parameters instantly
        String baseUrl = "file:///android_asset/map.html";
        String params = "?elderLat=" + elderLat +
                        "&elderLng=" + elderLng +
                        "&elderName=" + Uri.encode(elderName);
        
        webView.loadUrl(baseUrl + params);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            webView.clearHistory();
            ((android.view.ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
