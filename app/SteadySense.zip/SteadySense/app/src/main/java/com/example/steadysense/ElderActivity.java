package com.example.steadysense;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.example.steadysense.services.FallDetectionService;

public class ElderActivity extends BaseActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    
    private final androidx.activity.result.ActivityResultLauncher<String[]> requestPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean allGranted = true;
                for (Boolean granted : result.values()) {
                    if (!granted) {
                        allGranted = false;
                        break;
                    }
                }
                if (allGranted) {
                    startFallDetectionService();
                } else {
                    android.widget.Toast.makeText(this, "Permissions required for fall detection and voice", android.widget.Toast.LENGTH_LONG).show();
                }
            });

    private View voiceAssistantCard, logoutCard, sosButtonView;
    private com.google.android.material.button.MaterialButton langButtonDash;
    private TextView statusText, riskLevelText, welcomeText;
    private android.widget.LinearLayout caretakersContainer;
    private com.google.android.material.button.MaterialButton addCaretakerBtn;
    private com.google.firebase.firestore.ListenerRegistration userListenerRegistration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elder);

        logoutCard = findViewById(R.id.logoutCard);
        sosButtonView = findViewById(R.id.sosButton);
        voiceAssistantCard = findViewById(R.id.voiceAssistantCard);
        langButtonDash = (com.google.android.material.button.MaterialButton) findViewById(R.id.langButtonDash);
        statusText = findViewById(R.id.statusText);
        riskLevelText = findViewById(R.id.riskLevelText);
        welcomeText = findViewById(R.id.welcomeText);

        loadUserData();
        checkPermissions();
        setupCaretakersSection();

        voiceAssistantCard.setOnClickListener(v -> {
            startActivity(new Intent(ElderActivity.this, VoiceAssistantActivity.class));
        });

        langButtonDash.setText(com.example.steadysense.helpers.LocaleHelper.getLanguage(this).equals("ur") ? "English" : "اردو");
        langButtonDash.setOnClickListener(v -> {
            String currentLang = com.example.steadysense.helpers.LocaleHelper.getLanguage(this);
            String newLang = currentLang.equals("ur") ? "en" : "ur";
            com.example.steadysense.helpers.LocaleHelper.setLocale(this, newLang);
            recreate();
        });

        logoutCard.setOnClickListener(v -> {
            stopService(new Intent(this, FallDetectionService.class));
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(ElderActivity.this, LoginActivity.class));
            finish();
        });

        sosButtonView.setOnLongClickListener(v -> {
            com.example.steadysense.helpers.AlertManager alertManager = new com.example.steadysense.helpers.AlertManager(this);
            alertManager.triggerEmergency("SOS_MANUAL");
            return true;
        });

        sosButtonView.setOnClickListener(v -> {
            Intent intent = new Intent(this, FallAlertActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.historyCard).setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceHistoryActivity.class);
            intent.putExtra("elderUid", FirebaseAuth.getInstance().getUid());
            intent.putExtra("elderName", "My");
            startActivity(intent);
        });

        // Premium Bottom Navigation Bar Tab Listeners
        findViewById(R.id.tabHome).setOnClickListener(v -> {
            android.widget.ScrollView scrollView = findViewById(R.id.mainScrollView);
            if (scrollView != null) {
                scrollView.smoothScrollTo(0, 0);
            }
        });

        findViewById(R.id.tabVoice).setOnClickListener(v -> {
            startActivity(new Intent(ElderActivity.this, VoiceAssistantActivity.class));
        });

        findViewById(R.id.tabHistory).setOnClickListener(v -> {
            Intent intent = new Intent(ElderActivity.this, VoiceHistoryActivity.class);
            intent.putExtra("elderUid", FirebaseAuth.getInstance().getUid());
            intent.putExtra("elderName", "My");
            startActivity(intent);
        });

        findViewById(R.id.tabCaretakers).setOnClickListener(v -> {
            android.view.View caretakersCard = findViewById(R.id.caretakersCard);
            android.widget.ScrollView scrollView = findViewById(R.id.mainScrollView);
            if (caretakersCard != null && scrollView != null) {
                scrollView.smoothScrollTo(0, caretakersCard.getTop());
            }
        });

        findViewById(R.id.tabLogout).setOnClickListener(v -> {
            stopService(new Intent(this, FallDetectionService.class));
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(ElderActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void loadUserData() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String name = documentSnapshot.getString("name");
                        if (name != null && !name.isEmpty() && welcomeText != null) {
                            welcomeText.setText(getString(R.string.hello_format, name));
                        }
                    }
                });
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            java.util.List<String> permissionList = new java.util.ArrayList<>();
            
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionList.add(Manifest.permission.RECORD_AUDIO);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                permissionList.add(Manifest.permission.ACTIVITY_RECOGNITION);
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionList.add(Manifest.permission.POST_NOTIFICATIONS);
            }

            String[] permissions = permissionList.toArray(new String[0]);
            boolean allGranted = true;
            for (String p : permissions) {
                if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (!allGranted) {
                requestPermissionLauncher.launch(permissions);
            } else {
                startFallDetectionService();
            }
        } else {
            startFallDetectionService();
        }
    }


    private void startFallDetectionService() {
        Intent serviceIntent = new Intent(this, FallDetectionService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        if (statusText != null) {
            statusText.setText(R.string.monitoring_active);
        }
    }

    private void setupCaretakersSection() {
        caretakersContainer = findViewById(R.id.caretakersContainer);
        addCaretakerBtn = findViewById(R.id.addCaretakerBtn);

        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        userListenerRegistration = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users")
                .document(uid)
                .addSnapshotListener((documentSnapshot, error) -> {
                    if (error != null) {
                        android.util.Log.e("ElderActivity", "Listen to user document failed", error);
                        return;
                    }

                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        com.example.steadysense.models.User elder = documentSnapshot.toObject(com.example.steadysense.models.User.class);
                        if (elder != null) {
                            java.util.List<String> cIds = elder.getCaretakerIds();
                            if (cIds == null) {
                                cIds = new java.util.ArrayList<>();
                            }
                            if (elder.getCaretakerId() != null && !elder.getCaretakerId().isEmpty() && !cIds.contains(elder.getCaretakerId())) {
                                cIds.add(elder.getCaretakerId());
                                com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(uid)
                                        .update("caretakerIds", com.google.firebase.firestore.FieldValue.arrayUnion(elder.getCaretakerId()));
                            }
                            displayCaretakers(cIds);
                        }
                    }
                });

        addCaretakerBtn.setOnClickListener(v -> showAddCaretakerDialog());
    }

    private void displayCaretakers(java.util.List<String> caretakerIds) {
        if (caretakersContainer == null) return;
        caretakersContainer.removeAllViews();

        if (caretakerIds.isEmpty()) {
            android.widget.TextView emptyTextView = new android.widget.TextView(this);
            emptyTextView.setText(com.example.steadysense.helpers.LocaleHelper.getLanguage(this).equals("ur") ? "ابھی کوئی مددگار لنک نہیں ہے" : "No caretakers linked yet");
            emptyTextView.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.claude_text_secondary));
            emptyTextView.setTextSize(14.0f);
            emptyTextView.setGravity(android.view.Gravity.CENTER);
            emptyTextView.setPadding(0, 16, 0, 16);
            caretakersContainer.addView(emptyTextView);
            return;
        }

        for (String cId : caretakerIds) {
            final String currentCId = cId;
            
            android.widget.LinearLayout rowLayout = new android.widget.LinearLayout(this);
            rowLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            rowLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
            rowLayout.setPadding(8, 8, 8, 8);
            
            android.widget.ImageView personIcon = new android.widget.ImageView(this);
            personIcon.setImageResource(android.R.drawable.ic_menu_myplaces);
            personIcon.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.claude_accent));
            
            android.widget.LinearLayout textLayout = new android.widget.LinearLayout(this);
            textLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
            textLayout.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            textLayout.setPadding(16, 0, 16, 0);
            
            android.widget.TextView idTextView = new android.widget.TextView(this);
            idTextView.setText("#" + currentCId);
            idTextView.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.claude_text_primary));
            idTextView.setTextSize(16.0f);
            idTextView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            
            android.widget.TextView emailTextView = new android.widget.TextView(this);
            emailTextView.setText(com.example.steadysense.helpers.LocaleHelper.getLanguage(this).equals("ur") ? "لوڈنگ..." : "Loading caretaker details...");
            emailTextView.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.claude_text_secondary));
            emailTextView.setTextSize(12.0f);
            
            textLayout.addView(idTextView);
            textLayout.addView(emailTextView);
            
            android.widget.ImageView removeIcon = new android.widget.ImageView(this);
            removeIcon.setImageResource(android.R.drawable.ic_menu_delete);
            removeIcon.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.status_red));
            removeIcon.setClickable(true);
            removeIcon.setFocusable(true);
            
            android.widget.LinearLayout.LayoutParams iconParams = new android.widget.LinearLayout.LayoutParams(
                    (int) (32 * getResources().getDisplayMetrics().density),
                    (int) (32 * getResources().getDisplayMetrics().density)
            );
            personIcon.setLayoutParams(iconParams);
            
            android.widget.LinearLayout.LayoutParams removeParams = new android.widget.LinearLayout.LayoutParams(
                    (int) (28 * getResources().getDisplayMetrics().density),
                    (int) (28 * getResources().getDisplayMetrics().density)
            );
            removeIcon.setLayoutParams(removeParams);
            
            rowLayout.addView(personIcon);
            rowLayout.addView(textLayout);
            rowLayout.addView(removeIcon);
            
            caretakersContainer.addView(rowLayout);

            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    .collection("users")
                    .whereEqualTo("role", "Caretaker")
                    .get()
                    .addOnSuccessListener(querySnapshot -> {
                        if (querySnapshot != null) {
                            for (com.google.firebase.firestore.DocumentSnapshot doc : querySnapshot.getDocuments()) {
                                String uid = doc.getId();
                                String resolvedId = uid.substring(0, 6).toUpperCase();
                                if (resolvedId.equals(currentCId)) {
                                    String name = doc.getString("name");
                                    String email = doc.getString("email");
                                    if (name != null && email != null) {
                                        idTextView.setText(name + " (#" + currentCId + ")");
                                        emailTextView.setText(email);
                                    }
                                    break;
                                }
                            }
                        }
                    });

            removeIcon.setOnClickListener(v -> showRemoveCaretakerDialog(currentCId));
            
            android.view.View divider = new android.view.View(this);
            android.widget.LinearLayout.LayoutParams divParams = new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    (int) (1 * getResources().getDisplayMetrics().density)
            );
            divParams.setMargins(0, 8, 0, 8);
            divider.setLayoutParams(divParams);
            divider.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.claude_border));
            caretakersContainer.addView(divider);
        }
        
        if (caretakersContainer.getChildCount() > 0) {
            caretakersContainer.removeViewAt(caretakersContainer.getChildCount() - 1);
        }
    }

    private void showAddCaretakerDialog() {
        android.widget.EditText input = new android.widget.EditText(this);
        input.setHint(R.string.caretaker_id_placeholder);
        input.setSingleLine(true);
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6), new android.text.InputFilter.AllCaps()});
        
        android.widget.FrameLayout container = new android.widget.FrameLayout(this);
        android.widget.FrameLayout.LayoutParams params = new android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = (int) (24 * getResources().getDisplayMetrics().density);
        params.rightMargin = (int) (24 * getResources().getDisplayMetrics().density);
        params.topMargin = (int) (8 * getResources().getDisplayMetrics().density);
        params.bottomMargin = (int) (8 * getResources().getDisplayMetrics().density);
        input.setLayoutParams(params);
        container.addView(input);

        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(R.string.caretaker_id_dialog_title)
                .setMessage(R.string.caretaker_id_dialog_message)
                .setView(container)
                .setPositiveButton(R.string.add, (dialog, which) -> {
                    String rawId = input.getText().toString().trim().toUpperCase();
                    if (rawId.length() < 6) {
                        Toast.makeText(this, 
                                com.example.steadysense.helpers.LocaleHelper.getLanguage(this).equals("ur") ? "براہ کرم 6 ہندسوں کا درست کوڈ لکھیں" : "Please enter a valid 6-digit ID", 
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    validateAndAddCaretaker(rawId);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void validateAndAddCaretaker(String code) {
        String elderUid = FirebaseAuth.getInstance().getUid();
        if (elderUid == null) return;

        com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users")
                .whereEqualTo("role", "Caretaker")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    boolean found = false;
                    String matchedCId = null;
                    if (querySnapshot != null) {
                        for (com.google.firebase.firestore.DocumentSnapshot doc : querySnapshot.getDocuments()) {
                            String uid = doc.getId();
                            String resolvedId = uid.substring(0, 6).toUpperCase();
                            if (resolvedId.equals(code)) {
                                found = true;
                                matchedCId = resolvedId;
                                break;
                            }
                        }
                    }

                    if (found && matchedCId != null) {
                        final String finalMatchedCId = matchedCId;
                        com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                .collection("users")
                                .document(elderUid)
                                .update("caretakerIds", com.google.firebase.firestore.FieldValue.arrayUnion(finalMatchedCId))
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(ElderActivity.this, 
                                            com.example.steadysense.helpers.LocaleHelper.getLanguage(ElderActivity.this).equals("ur") ? "مددگار کامیابی سے لنک ہو گیا ہے!" : "Caretaker linked successfully!", 
                                            Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(ElderActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        new com.google.android.material.dialog.MaterialAlertDialogBuilder(ElderActivity.this)
                                .setTitle(com.example.steadysense.helpers.LocaleHelper.getLanguage(ElderActivity.this).equals("ur") ? "غلط آئی ڈی" : "Invalid Caretaker ID")
                                .setMessage(com.example.steadysense.helpers.LocaleHelper.getLanguage(ElderActivity.this).equals("ur") ? "یہ آئی ڈی موجود نہیں ہے۔ براہ کرم چیک کریں اور دوبارہ کوشش کریں۔" : "This Caretaker ID does not exist. Please check and try again.")
                                .setPositiveButton(R.string.i_am_okay, null)
                                .show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ElderActivity.this, "Firestore Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void showRemoveCaretakerDialog(String targetCId) {
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(R.string.remove_caretaker_title)
                .setMessage(R.string.remove_caretaker_msg)
                .setPositiveButton(R.string.remove, (dialog, which) -> {
                    String elderUid = FirebaseAuth.getInstance().getUid();
                    if (elderUid == null) return;

                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                            .collection("users")
                            .document(elderUid)
                            .update("caretakerIds", com.google.firebase.firestore.FieldValue.arrayRemove(targetCId))
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(ElderActivity.this, 
                                        com.example.steadysense.helpers.LocaleHelper.getLanguage(ElderActivity.this).equals("ur") ? "مددگار ہٹا دیا گیا ہے!" : "Caretaker unlinked successfully!", 
                                        Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(ElderActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (userListenerRegistration != null) {
            userListenerRegistration.remove();
        }
    }
}
