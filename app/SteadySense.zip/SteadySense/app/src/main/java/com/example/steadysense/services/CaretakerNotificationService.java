package com.example.steadysense.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.steadysense.CaretakerActivity;
import com.example.steadysense.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

public class CaretakerNotificationService extends Service {

    private static final String TAG = "CaretakerNotifService";
    private static final String CHANNEL_FOREGROUND_ID = "CaretakerForegroundChannel";
    private static final String CHANNEL_ALERT_ID = "CaretakerAlertChannel";
    
    private FirebaseFirestore db;
    private ListenerRegistration alertListener;
    private String caretakerId;
    private long serviceStartTime;

    @Override
    public void onCreate() {
        super.onCreate();
        db = FirebaseFirestore.getInstance();
        serviceStartTime = System.currentTimeMillis();
        createNotificationChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            caretakerId = intent.getStringExtra("caretakerId");
        }

        if (caretakerId == null || caretakerId.isEmpty()) {
            String uid = FirebaseAuth.getInstance().getUid();
            if (uid != null && uid.length() >= 6) {
                caretakerId = uid.substring(0, 6).toUpperCase();
            }
        }

        // Start Foreground to ensure the system keeps the listener alive even when app is closed
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_FOREGROUND_ID)
                .setContentTitle("SteadySense Care Portal")
                .setContentText("Listening in background for elder safety alerts.")
                .setSmallIcon(R.drawable.steadysense_logo)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(2, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(2, notification);
        }

        if (caretakerId != null && !caretakerId.isEmpty()) {
            startListeningForAlerts();
        } else {
            Log.e(TAG, "No caretaker ID available. Stopping service.");
            stopSelf();
        }

        return START_STICKY;
    }

    private void startListeningForAlerts() {
        if (alertListener != null) alertListener.remove();

        Log.d(TAG, "Start listening for alerts for caretaker ID: " + caretakerId);
        alertListener = db.collection("events")
                .whereEqualTo("caretakerId", caretakerId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e(TAG, "Snapshot listener error", error);
                        return;
                    }
                    if (value != null && !value.isEmpty()) {
                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                String type = dc.getDocument().getString("type");
                                String elderName = dc.getDocument().getString("elderName");
                                String location = dc.getDocument().getString("location");
                                Long ts = dc.getDocument().getLong("timestamp");

                                if (ts != null && ts > serviceStartTime) {
                                    triggerSystemNotification(elderName, type, location);
                                }
                            }
                        }
                    }
                });
    }

    private void triggerSystemNotification(String name, String type, String location) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        // Intent to open CaretakerActivity when clicking notification
        Intent intent = new Intent(this, CaretakerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 
                0, 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String alertTitle = "🚨 EMERGENCY ALERT";
        String alertMessage = name + " has triggered: " + type + "!";

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        if (soundUri == null) {
            soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ALERT_ID)
                .setSmallIcon(R.drawable.steadysense_logo)
                .setContentTitle(alertTitle)
                .setContentText(alertMessage)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(alertMessage + "\n\nImmediate attention required. Tap to view location and log details."))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setSound(soundUri)
                .setVibrate(new long[]{0, 1000, 500, 1000, 500, 1000})
                .setAutoCancel(true)
                .setFullScreenIntent(pendingIntent, true) // Show heads-up alert banner
                .setContentIntent(pendingIntent);

        manager.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;

            // Channel 1: Foreground service persistent notice
            NotificationChannel channelForeground = new NotificationChannel(
                    CHANNEL_FOREGROUND_ID,
                    "Caretaker Background Monitor",
                    NotificationManager.IMPORTANCE_LOW
            );
            channelForeground.setDescription("Keeps caretaker active background alert listener running.");
            manager.createNotificationChannel(channelForeground);

            // Channel 2: High-priority emergency alerts
            NotificationChannel channelAlert = new NotificationChannel(
                    CHANNEL_ALERT_ID,
                    "Elder Emergency Alerts",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channelAlert.setDescription("Urgent alerts for falls and manual SOS triggers.");
            channelAlert.enableLights(true);
            channelAlert.setLightColor(android.graphics.Color.RED);
            channelAlert.enableVibration(true);
            
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }
            
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build();
            channelAlert.setSound(soundUri, audioAttributes);

            manager.createNotificationChannel(channelAlert);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (alertListener != null) {
            alertListener.remove();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
