package com.example.steadysense.helpers;

import android.os.AsyncTask;
import android.util.Log;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailHelper {

    // IMPORTANT: You must use a Gmail "App Password" here, not your real password.
    // Go to Google Account Settings -> Security -> App Passwords to create one.
    private static final String SENDER_EMAIL = "sulta4567@gmail.com"; 
    private static final String SENDER_PASSWORD = "xmlw ptsg vfsn bfqh"; 

    public static void sendEmailDirect(String recipientEmail, String subject, String messageContent) {
        new SendEmailTask(recipientEmail, subject, messageContent).execute();
    }

    private static class SendEmailTask extends AsyncTask<Void, Void, Boolean> {
        private String recipient;
        private String subject;
        private String content;

        public SendEmailTask(String recipient, String subject, String content) {
            this.recipient = recipient;
            this.subject = subject;
            this.content = content;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true"); // Use SSL for Port 465
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "465");

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
                }
            });

            try {
                Message message = new MimeMessage(session);
                try {
                    message.setFrom(new InternetAddress(SENDER_EMAIL, "SteadySense"));
                } catch (java.io.UnsupportedEncodingException e) {
                    message.setFrom(new InternetAddress(SENDER_EMAIL));
                }
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
                message.setSubject(subject);
                message.setText(content);

                Transport.send(message);
                Log.d("EmailHelper", "Direct email sent successfully to " + recipient);
                return true;
            } catch (MessagingException e) {
                Log.e("EmailHelper", "Failed to send direct email", e);
                return false;
            }
        }
    }
}
