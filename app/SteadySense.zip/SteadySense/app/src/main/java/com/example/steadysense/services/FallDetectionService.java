package com.example.steadysense.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.steadysense.FallAlertActivity;
import com.example.steadysense.R;
import com.example.steadysense.models.HealthReading;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class FallDetectionService extends Service implements SensorEventListener {

    private static final String TAG = "FallDetectionService";
    private static final String CHANNEL_ID = "FallDetectionChannel";
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private com.example.steadysense.helpers.GeminiHelper geminiHelper;
    private com.example.steadysense.helpers.AlertManager alertManager;
    private android.os.PowerManager.WakeLock wakeLock;

    private final android.content.BroadcastReceiver screenReceiver = new android.content.BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null) {
                if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                    Log.d(TAG, "Screen off received. Re-registering sensor listener.");
                    if (sensorManager != null && accelerometer != null) {
                        sensorManager.unregisterListener(FallDetectionService.this);
                        sensorManager.registerListener(FallDetectionService.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                    }
                } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                    Log.d(TAG, "Screen on received. Restoring sensor listener.");
                    if (sensorManager != null && accelerometer != null) {
                        sensorManager.unregisterListener(FallDetectionService.this);
                        sensorManager.registerListener(FallDetectionService.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                    }
                }
            }
        }
    };
    
    private static final float FALL_THRESHOLD = 35.0f; // Increased from 25.0f to reduce false positives
    private static final long INACTIVITY_WAIT_TIME = 3000;
    private static final long TRIGGER_COOLDOWN = 15000;
    
    private boolean impactDetected = false;
    private long impactTime = 0;
    private long lastTriggerTime = 0;
    private boolean inactivityCheckFired = false;
    
    private long lastSyncTime = 0;
    private static final long SYNC_INTERVAL = 60000;
    private int stepCount = 0;
    private float lastStepMagnitude = 0;
    private String currentActivity = "Resting";

    private com.example.steadysense.helpers.LocationHelper locationHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        geminiHelper = new com.example.steadysense.helpers.GeminiHelper();
        alertManager = new com.example.steadysense.helpers.AlertManager(this);
        locationHelper = new com.example.steadysense.helpers.LocationHelper(this);
        
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        android.os.PowerManager powerManager = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "SteadySense:FallDetection");
        wakeLock.acquire();

        // Register screen state receiver to ensure sensor readings continue when screen is turned off
        android.content.IntentFilter filter = new android.content.IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenReceiver, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("SteadySense Monitoring")
                .setContentText("Fall detection is running in the background.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Health was added in API 34, so for Q-33 we might use something else or just standard startForeground
            startForeground(1, notification);
        } else {
            startForeground(1, notification);
        }
        return START_STICKY;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            double accelerationMagnitude = Math.sqrt(x * x + y * y + z * z);

            long currentTime = System.currentTimeMillis();

            // Activity Classification with debounced step counting
            if (accelerationMagnitude > 16) {
                currentActivity = "Walking";
                if (Math.abs(accelerationMagnitude - lastStepMagnitude) > 3.0) {
                    stepCount++;
                    lastStepMagnitude = (float) accelerationMagnitude;
                }
            } else if (accelerationMagnitude < 3) {
                currentActivity = "Sleeping/Lying";
            } else {
                currentActivity = "Resting";
            }

            // Periodic Health Sync
            if (currentTime - lastSyncTime > SYNC_INTERVAL) {
                syncHealthStatus(accelerationMagnitude);
                lastSyncTime = currentTime;
            }

            // Cooldown check to prevent repeated triggers
            if (currentTime - lastTriggerTime < TRIGGER_COOLDOWN) return;

            if (accelerationMagnitude > 50.0f && currentTime - lastTriggerTime > TRIGGER_COOLDOWN) { // Increased from 35.0f
                Log.d(TAG, "Extreme Impact detected! Magnitude: " + accelerationMagnitude);
                triggerFallAlert();
                lastTriggerTime = currentTime;
                impactDetected = false;
            } else if (accelerationMagnitude > FALL_THRESHOLD) {
                Log.d(TAG, "Impact detected! Magnitude: " + accelerationMagnitude);
                impactDetected = true;
                impactTime = currentTime;
                inactivityCheckFired = false;
            }

            if (impactDetected && !inactivityCheckFired && (currentTime - impactTime > INACTIVITY_WAIT_TIME)) {
                inactivityCheckFired = true;
                // Confirm the elder is completely inactive/still (acceleration is near gravity 9.8 m/s^2)
                if (Math.abs(accelerationMagnitude - 9.8) < 1.2) {
                    Log.d(TAG, "Fall confirmed after inactivity! Triggering alert.");
                    triggerFallAlert();
                    lastTriggerTime = currentTime;
                }
                impactDetected = false;
            }
        }
    }

    private void triggerFallAlert() {
        // Send email and log to Firestore via AlertManager
        alertManager.triggerEmergency("FALL_DETECTED");

        // Show the alert activity
        Intent intent = new Intent(this, FallAlertActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void syncHealthStatus(double magnitude) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        locationHelper.getCurrentLocation(locationLink -> {
            HealthReading reading = new HealthReading(
                    System.currentTimeMillis(),
                    stepCount,
                    currentActivity,
                    magnitude,
                    true
            );

            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(uid)
                    .collection("health_readings")
                    .add(reading);

            // Update real-time status for Caretaker dashboard
            Map<String, Object> update = new HashMap<>();
            update.put("lastActivity", currentActivity);
            update.put("stepCount", stepCount);
            update.put("lastPulse", System.currentTimeMillis());
            if (locationLink != null) {
                update.put("lastKnownLocation", locationLink);
            }

            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(uid)
                    .update(update);
        });
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Fall Detection Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        sensorManager.unregisterListener(this);
        try {
            unregisterReceiver(screenReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering screenReceiver", e);
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }
}
