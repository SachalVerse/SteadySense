package com.example.steadysense.helpers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class LocationHelper {

    private static final String TAG = "LocationHelper";
    private final Context context;
    private final FusedLocationProviderClient fusedLocationClient;

    public LocationHelper(Context context) {
        this.context = context;
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
    }

    public interface LocationCallback {
        void onLocationResult(String locationLink);
    }

    private String getMapLink(Location location) {
        return "https://www.google.com/maps/search/?api=1&query=" + 
               location.getLatitude() + "," + location.getLongitude();
    }

    private void saveLastLocationToCache(double lat, double lng) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("SteadySenseLocationCache", Context.MODE_PRIVATE);
            prefs.edit()
                 .putFloat("last_lat", (float) lat)
                 .putFloat("last_lng", (float) lng)
                 .putLong("last_time", System.currentTimeMillis())
                 .apply();
            Log.d(TAG, "Successfully cached location in SharedPreferences: " + lat + ", " + lng);
        } catch (Exception e) {
            Log.e(TAG, "Error caching location in SharedPreferences", e);
        }
    }

    private String getFallbackLink() {
        try {
            SharedPreferences prefs = context.getSharedPreferences("SteadySenseLocationCache", Context.MODE_PRIVATE);
            float cachedLat = prefs.getFloat("last_lat", 0.0f);
            float cachedLng = prefs.getFloat("last_lng", 0.0f);
            if (cachedLat != 0.0f && cachedLng != 0.0f) {
                Log.d(TAG, "Using SharedPreferences cached location fallback: " + cachedLat + ", " + cachedLng);
                return "https://www.google.com/maps/search/?api=1&query=" + cachedLat + "," + cachedLng;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error reading SharedPreferences cache, using default", e);
        }
        // Safe, standard placeholder coordinates (Islamabad city center) as ultimate fallback
        return "https://www.google.com/maps/search/?api=1&query=33.6844,73.0479";
    }

    @SuppressLint("MissingPermission")
    public void getCurrentLocation(LocationCallback callback) {
        Log.d(TAG, "getCurrentLocation requested. Querying fresh current location first.");
        try {
            // Priority 100 = PRIORITY_HIGH_ACCURACY
            fusedLocationClient.getCurrentLocation(100, null)
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            Log.d(TAG, "Fused fresh location found: " + location.getLatitude() + ", " + location.getLongitude());
                            saveLastLocationToCache(location.getLatitude(), location.getLongitude());
                            callback.onLocationResult(getMapLink(location));
                        } else {
                            Log.d(TAG, "Fused fresh location is null. Trying fused last location.");
                            tryFusedLastLocation(callback);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Fused fresh location failed. Trying fused last location.", e);
                        tryFusedLastLocation(callback);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error in getCurrentLocation. Trying fused last location.", e);
            tryFusedLastLocation(callback);
        }
    }

    @SuppressLint("MissingPermission")
    private void tryFusedLastLocation(LocationCallback callback) {
        try {
            Log.d(TAG, "Attempting fused last location.");
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            Log.d(TAG, "Fused last location found: " + location.getLatitude() + ", " + location.getLongitude());
                            saveLastLocationToCache(location.getLatitude(), location.getLongitude());
                            callback.onLocationResult(getMapLink(location));
                        } else {
                            Log.d(TAG, "Fused last location is null. Querying native LocationManager.");
                            tryNativeLocationManager(callback);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Fused last location failed. Querying native LocationManager.", e);
                        tryNativeLocationManager(callback);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error in getLastLocation. Querying native LocationManager.", e);
            tryNativeLocationManager(callback);
        }
    }

    @SuppressLint("MissingPermission")
    private void tryNativeLocationManager(LocationCallback callback) {
        try {
            android.location.LocationManager lm = (android.location.LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                android.location.Location loc = null;
                
                // Try GPS Provider first (high accuracy)
                if (lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
                    loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
                    if (loc != null) {
                        Log.d(TAG, "Native GPS last known location found: " + loc.getLatitude() + ", " + loc.getLongitude());
                        saveLastLocationToCache(loc.getLatitude(), loc.getLongitude());
                        callback.onLocationResult(getMapLink(loc));
                        return;
                    }
                }
                
                // Try Network Provider next
                if (lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)) {
                    loc = lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER);
                    if (loc != null) {
                        Log.d(TAG, "Native Network last known location found: " + loc.getLatitude() + ", " + loc.getLongitude());
                        saveLastLocationToCache(loc.getLatitude(), loc.getLongitude());
                        callback.onLocationResult(getMapLink(loc));
                        return;
                    }
                }

                // If both cached native locations are null, request an active single update
                final android.location.LocationListener locationListener = new android.location.LocationListener() {
                    @Override
                    public void onLocationChanged(android.location.Location location) {
                        if (location != null) {
                            Log.d(TAG, "Active GPS/Network single location captured: " + location.getLatitude() + ", " + location.getLongitude());
                            saveLastLocationToCache(location.getLatitude(), location.getLongitude());
                            callback.onLocationResult(getMapLink(location));
                        } else {
                            callback.onLocationResult(getFallbackLink());
                        }
                        try {
                            lm.removeUpdates(this);
                        } catch (Exception ex) {
                            Log.e(TAG, "Error removing native updates", ex);
                        }
                    }
                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override
                    public void onProviderEnabled(String provider) {}
                    @Override
                    public void onProviderDisabled(String provider) {}
                };

                // Request single updates
                if (lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
                    Log.d(TAG, "Requesting single location update from GPS provider.");
                    lm.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER, 0, 0, locationListener, android.os.Looper.getMainLooper());
                    
                    // Setup a 4-second timeout to fall back to network if GPS doesn't respond instantly
                    new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                        try {
                            lm.removeUpdates(locationListener);
                        } catch (Exception e) {}
                        requestNetworkLocation(callback, lm);
                    }, 4000);
                } else {
                    requestNetworkLocation(callback, lm);
                }
            } else {
                Log.d(TAG, "LocationManager is null. Falling back to cache.");
                callback.onLocationResult(getFallbackLink());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in native LocationManager. Falling back to cache.", e);
            callback.onLocationResult(getFallbackLink());
        }
    }

    @SuppressLint("MissingPermission")
    private void requestNetworkLocation(LocationCallback callback, android.location.LocationManager lm) {
        try {
            if (lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)) {
                Log.d(TAG, "Requesting single location update from Network provider.");
                lm.requestLocationUpdates(android.location.LocationManager.NETWORK_PROVIDER, 0, 0, new android.location.LocationListener() {
                    @Override
                    public void onLocationChanged(android.location.Location location) {
                        if (location != null) {
                            Log.d(TAG, "Active Network location captured: " + location.getLatitude() + ", " + location.getLongitude());
                            saveLastLocationToCache(location.getLatitude(), location.getLongitude());
                            callback.onLocationResult(getMapLink(location));
                        } else {
                            callback.onLocationResult(getFallbackLink());
                        }
                        try {
                            lm.removeUpdates(this);
                        } catch (Exception ex) {}
                    }
                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override
                    public void onProviderEnabled(String provider) {}
                    @Override
                    public void onProviderDisabled(String provider) {}
                }, android.os.Looper.getMainLooper());
            } else {
                Log.d(TAG, "Network provider disabled. Falling back to cache.");
                callback.onLocationResult(getFallbackLink());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error requesting active Network location. Falling back to cache.", e);
            callback.onLocationResult(getFallbackLink());
        }
    }
}
