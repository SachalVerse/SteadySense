package com.example.steadysense;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.example.steadysense.models.User;
import java.util.ArrayList;
import java.util.List;

public class CaretakerActivity extends BaseActivity {

    private TextView caretakerIdDisplay;
    private RecyclerView elderRecyclerView;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String caretakerId;
    private View emptyState;
    private com.example.steadysense.adapters.ElderAdapter adapter;
    private List<User> elderList = new ArrayList<>();
    private long lastAlertTimestamp = System.currentTimeMillis();
    private com.google.firebase.firestore.ListenerRegistration elderListener;

    private final androidx.activity.result.ActivityResultLauncher<String> requestNotificationPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    startNotificationService();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        caretakerIdDisplay = findViewById(R.id.caretakerIdDisplay);
        emptyState = findViewById(R.id.emptyState);
        elderRecyclerView = findViewById(R.id.elderRecyclerView);
        caretakerId = mAuth.getCurrentUser().getUid().substring(0, 6).toUpperCase();
        caretakerIdDisplay.setText("ID: #" + caretakerId);

        elderRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new com.example.steadysense.adapters.ElderAdapter(elderList);
        elderRecyclerView.setAdapter(adapter);
        
        startListeningForElders();
        listenForAlerts();

        // Premium Floating Bottom Navigation Bar Listeners
        findViewById(R.id.tabCaretakerHome).setOnClickListener(v -> {
            android.widget.ScrollView scrollView = findViewById(R.id.caretakerScrollView);
            if (scrollView != null) {
                scrollView.smoothScrollTo(0, 0);
            }
        });



        findViewById(R.id.addElderBtn).setOnClickListener(v -> showAddElderDialog());
        findViewById(R.id.tabCaretakerLink).setOnClickListener(v -> showAddElderDialog());

        findViewById(R.id.tabCaretakerLogout).setOnClickListener(v -> {
            stopService(new Intent(this, com.example.steadysense.services.CaretakerNotificationService.class));
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(CaretakerActivity.this, LoginActivity.class));
            finish();
        });

        checkAndStartNotificationService();
    }

    private void checkAndStartNotificationService() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) 
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
            } else {
                startNotificationService();
            }
        } else {
            startNotificationService();
        }
    }

    private void startNotificationService() {
        Intent serviceIntent = new Intent(this, com.example.steadysense.services.CaretakerNotificationService.class);
        serviceIntent.putExtra("caretakerId", caretakerId);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }



    private void startListeningForElders() {
        if (elderListener != null) elderListener.remove();
        
        elderListener = db.collection("users")
                .whereEqualTo("role", "Elder")
                .whereArrayContains("caretakerIds", caretakerId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        android.util.Log.e("CaretakerActivity", "Listen failed.", error);
                        return;
                    }
                    
                    elderList.clear();
                    if (value != null) {
                        for (com.google.firebase.firestore.DocumentSnapshot doc : value.getDocuments()) {
                            User u = doc.toObject(User.class);
                            if (u != null) elderList.add(u);
                        }
                    }
                    
                    if (elderList.isEmpty()) {
                        emptyState.setVisibility(View.VISIBLE);
                    } else {
                        emptyState.setVisibility(View.GONE);
                    }
                    
                    TextView activeCount = findViewById(R.id.activeCount);
                    if (activeCount != null) {
                        activeCount.setText(String.valueOf(elderList.size()));
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void listenForAlerts() {
        db.collection("events")
                .whereEqualTo("caretakerId", caretakerId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        android.util.Log.e("CaretakerActivity", "Alerts listen failed", error);
                        return;
                    }
                    if (value != null && !value.isEmpty()) {
                        for (com.google.firebase.firestore.DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                String elderName = dc.getDocument().getString("elderName");
                                String type = dc.getDocument().getString("type");
                                String location = dc.getDocument().getString("location");
                                Long ts = dc.getDocument().getLong("timestamp");
                                
                                if (ts != null && ts > lastAlertTimestamp) {
                                    lastAlertTimestamp = ts;
                                    showEmergencyDialog(elderName, type, location);
                                }
                            }
                        }
                    }
                });
    }

    private void showEmergencyDialog(String name, String type, String location) {
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("🚨 EMERGENCY ALERT")
                .setMessage("Elder: " + name + "\nEvent: " + type + "\n\nImmediate attention required!")
                .setPositiveButton("View Location", (dialog, which) -> {
                    double elderLat = 0.0;
                    double elderLng = 0.0;
                    if (location != null && location.contains("query=")) {
                        try {
                            String query = location.substring(location.indexOf("query=") + 6);
                            if (query.contains("&")) {
                                query = query.substring(0, query.indexOf("&"));
                            }
                            String[] parts = query.split(",");
                            elderLat = Double.parseDouble(parts[0]);
                            elderLng = Double.parseDouble(parts[1]);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (elderLat != 0.0 && elderLng != 0.0) {
                        Intent intent = new Intent(CaretakerActivity.this, MapActivity.class);
                        intent.putExtra("elderLat", elderLat);
                        intent.putExtra("elderLng", elderLng);
                        intent.putExtra("elderName", name);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, "Location coordinates unavailable", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Dismiss", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setCancelable(false)
                .show();
    }

    private void showAddElderDialog() {
        android.view.View dialogView = android.view.LayoutInflater.from(this).inflate(R.layout.dialog_add_person, null);
        com.google.android.material.textfield.TextInputEditText emailInput = dialogView.findViewById(R.id.emailInput);

        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(R.string.add_person_title)
                .setMessage(R.string.add_person_msg)
                .setView(dialogView)
                .setPositiveButton(R.string.link_button, (dialog, which) -> {
                    if (emailInput != null && emailInput.getText() != null) {
                        String email = emailInput.getText().toString().trim().toLowerCase();
                        if (email.isEmpty()) {
                            Toast.makeText(this, R.string.enter_email_error, Toast.LENGTH_SHORT).show();
                        } else {
                            linkElderByEmail(email);
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void linkElderByEmail(String email) {
        db.collection("users")
                .whereEqualTo("role", "Elder")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()) {
                        com.google.firebase.firestore.DocumentSnapshot elderDoc = queryDocumentSnapshots.getDocuments().get(0);
                        String elderUid = elderDoc.getId();
                        
                        db.collection("users")
                                .document(elderUid)
                                .update("caretakerIds", com.google.firebase.firestore.FieldValue.arrayUnion(caretakerId))
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(CaretakerActivity.this, 
                                            com.example.steadysense.helpers.LocaleHelper.getLanguage(CaretakerActivity.this).equals("ur") ? "بزرگ کامیابی سے لنک ہو گیا ہے!" : "Elder successfully linked!", 
                                            Toast.LENGTH_LONG).show();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(CaretakerActivity.this, "Error linking elder: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        new com.google.android.material.dialog.MaterialAlertDialogBuilder(CaretakerActivity.this)
                                .setTitle(com.example.steadysense.helpers.LocaleHelper.getLanguage(CaretakerActivity.this).equals("ur") ? "مریض نہیں ملا" : "Elder Not Found")
                                .setMessage(com.example.steadysense.helpers.LocaleHelper.getLanguage(CaretakerActivity.this).equals("ur") ? "اس ای میل ایڈریس کے ساتھ کوئی بزرگ صارف رجسٹرڈ نہیں ہے۔" : "No registered Elder found with this email address.")
                                .setPositiveButton(R.string.i_am_okay, null)
                                .show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(CaretakerActivity.this, "Error searching elder: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
