package com.example.steadysense.models;

public class User {
    private String userId;
    private String name;
    private String email;
    private String role; // "Elder" or "Caretaker"
    private int age;
    private String caretakerId; // Only for Elder
    private String caretakerEmail; // New field to directly store caretaker's email
    private java.util.List<String> caretakerIds = new java.util.ArrayList<>(); // List of all caretakers for Elder
    private String fcmToken;
    private String lastActivity;
    private int stepCount;
    private int alertTimerDuration; // Custom countdown duration for emergency alerts (seconds)

    private String lastKnownLocation;

    public User() {} // Required for Firestore

    public User(String userId, String name, String email, String role) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.role = role;
    }

    // Getters and Setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getCaretakerId() { return caretakerId; }
    public void setCaretakerId(String caretakerId) { this.caretakerId = caretakerId; }

    public String getCaretakerEmail() { return caretakerEmail; }
    public void setCaretakerEmail(String caretakerEmail) { this.caretakerEmail = caretakerEmail; }

    public java.util.List<String> getCaretakerIds() { return caretakerIds; }
    public void setCaretakerIds(java.util.List<String> caretakerIds) { this.caretakerIds = caretakerIds; }

    public String getFcmToken() { return fcmToken; }
    public void setFcmToken(String fcmToken) { this.fcmToken = fcmToken; }

    public String getLastActivity() { return lastActivity; }
    public void setLastActivity(String lastActivity) { this.lastActivity = lastActivity; }

    public int getStepCount() { return stepCount; }
    public void setStepCount(int stepCount) { this.stepCount = stepCount; }

    public int getAlertTimerDuration() { return alertTimerDuration; }
    public void setAlertTimerDuration(int alertTimerDuration) { this.alertTimerDuration = alertTimerDuration; }

    public String getLastKnownLocation() { return lastKnownLocation; }
    public void setLastKnownLocation(String lastKnownLocation) { this.lastKnownLocation = lastKnownLocation; }
}
