package com.example.steadysense;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.steadysense.helpers.GeminiHelper;
import com.example.steadysense.helpers.LocaleHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

import java.util.ArrayList;
import java.util.Locale;

public class VoiceAssistantActivity extends BaseActivity {

    private TextView chatHistoryText, listeningStatus;
    private android.widget.ScrollView chatScrollView;
    private FloatingActionButton micButton;
    private ProgressBar loadingBar;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private GeminiHelper geminiHelper;
    private boolean isListening = false;
    private boolean isActive = true;
    private boolean ttsStoppedByUser = false;
    private static final int PERMISSION_REQUEST_RECORD_AUDIO = 1;

    private final androidx.activity.result.ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    startListening();
                } else {
                    android.widget.Toast.makeText(this, "Permission denied to record audio", android.widget.Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_assistant);

        chatHistoryText = findViewById(R.id.chatHistoryText);
        chatScrollView = findViewById(R.id.chatScrollView);
        listeningStatus = findViewById(R.id.listeningStatus);
        micButton = findViewById(R.id.micButton);
        loadingBar = findViewById(R.id.aiLoadingBar);

        geminiHelper = new GeminiHelper();

        // Initialize TTS
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("ur", "PK"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
                
                tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        runOnUiThread(() -> listeningStatus.setText("AI is speaking..."));
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        if (!isActive || isFinishing() || ttsStoppedByUser) return;
                        runOnUiThread(() -> startListening());
                    }

                    @Override
                    public void onError(String utteranceId) {}
                });

                speak("Portal is ready. How can I help you? میں آپ کی کیا مدد کر سکتا ہوں؟");
            } else {
                Log.e("VoiceAssistant", "TTS Initialization failed!");
                Toast.makeText(this, "Speech output not available", Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize Speech Recognizer
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    listeningStatus.setText("Listening...");
                    micButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            getResources().getColor(R.color.status_red)));
                }

                @Override
                public void onBeginningOfSpeech() {}

                @Override
                public void onRmsChanged(float rmsdB) {}

                @Override
                public void onBufferReceived(byte[] buffer) {}

                @Override
                public void onEndOfSpeech() {
                    listeningStatus.setText("Processing...");
                    isListening = false;
                    micButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            getResources().getColor(R.color.claude_text_primary)));
                }

                @Override
                public void onError(int error) {
                    String message;
                    switch (error) {
                        case SpeechRecognizer.ERROR_AUDIO: message = "Audio recording error"; break;
                        case SpeechRecognizer.ERROR_CLIENT: message = "Client side error"; break;
                        case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: message = "Please allow microphone access"; break;
                        case SpeechRecognizer.ERROR_NETWORK: message = "Check your internet connection"; break;
                        case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: message = "Network timeout, try again"; break;
                        case SpeechRecognizer.ERROR_NO_MATCH: message = "Sorry, I didn't catch that. Please speak clearly."; break;
                        case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: message = "Please wait a moment..."; break;
                        case SpeechRecognizer.ERROR_SERVER: message = "Server error, please try again"; break;
                        case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: message = "No speech detected. Tap mic to try again."; break;
                        default: message = "Something went wrong"; break;
                    }
                    listeningStatus.setText(message);
                    isListening = false;
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> data = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (data != null && !data.isEmpty()) {
                        String query = data.get(0);
                        updateChat("You: " + query);
                        getAiResponse(query);
                    }
                }

                @Override
                public void onPartialResults(Bundle partialResults) {}

                @Override
                public void onEvent(int eventType, Bundle params) {}
            });
        } else {
            listeningStatus.setText("Speech recognition not available");
            micButton.setEnabled(false);
        }

        micButton.setOnClickListener(v -> {
            if (tts != null && tts.isSpeaking()) {
                ttsStoppedByUser = true;
                tts.stop();
            }
            if (!isListening) {
                checkPermissionAndStartListening();
            } else {
                speechRecognizer.stopListening();
            }
        });
    }

    private void updateChat(String text) {
        chatHistoryText.append("\n\n" + text);
        chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void checkPermissionAndStartListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO);
        } else {
            startListening();
        }
    }


    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        
        // Multi-language support configuration
        String lang = LocaleHelper.getLanguage(this);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.equals("ur") ? "ur-PK" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang.equals("ur") ? "ur-PK" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
        
        speechRecognizer.startListening(intent);
        isListening = true;
    }

    private void getAiResponse(String query) {
        loadingBar.setVisibility(View.VISIBLE);
        geminiHelper.getAiResponse(query, null, new GeminiHelper.GeminiResponseCallback() {
            @Override
            public void onSuccess(String response) {
                runOnUiThread(() -> {
                    loadingBar.setVisibility(View.GONE);
                    updateChat("AI: " + response);
                    speak(response);
                    saveConversation(query, response);
                });
            }

            @Override
            public void onFailure(Throwable t) {
                runOnUiThread(() -> {
                    loadingBar.setVisibility(View.GONE);
                    String errorMsg = "AI is currently unavailable. " + t.getMessage();
                    updateChat("Error: " + errorMsg);
                    speak(errorMsg);
                });
            }
        });
    }

    private void speak(String text) {
        if (tts != null) {
            String cleanText = text.replaceAll("[*#_~`>]", "");
            Log.d("VoiceAssistant", "Speaking: " + cleanText);

            Locale selectedLocale = Locale.US;
            if (cleanText.matches(".*[\\u0600-\\u06FF].*")) {
                selectedLocale = new Locale("ur", "PK");
            }

            int result = tts.setLanguage(selectedLocale);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("VoiceAssistant", "Language not supported: " + selectedLocale);
                if (selectedLocale.getLanguage().equals("ur")) {
                    Toast.makeText(this, "Urdu voice not supported on this device. Using English fallback.", Toast.LENGTH_SHORT).show();
                }
                tts.setLanguage(Locale.US);
            }

            tts.setPitch(1.1f); // Slightly higher pitch for a friendlier tone
            tts.setSpeechRate(0.9f); // Slightly slower for clearer, more natural speech
            tts.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "UtteranceID");
        } else {
            Log.e("VoiceAssistant", "TTS is null!");
        }
    }

    private void saveConversation(String userText, String aiText) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        Map<String, Object> message = new HashMap<>();
        message.put("user", userText);
        message.put("ai", aiText);
        message.put("timestamp", System.currentTimeMillis());

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(uid)
                .collection("conversations")
                .add(message);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isListening && speechRecognizer != null) {
            speechRecognizer.stopListening();
            isListening = false;
        }
    }

    @Override
    protected void onDestroy() {
        isActive = false;
        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
            speechRecognizer.destroy();
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
