package com.example.steadysense;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VoiceHistoryActivity extends BaseActivity {

    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private List<Map<String, Object>> messages = new ArrayList<>();
    private String elderUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_history);

        elderUid = getIntent().getStringExtra("elderUid");
        String elderName = getIntent().getStringExtra("elderName");
        
        TextView title = findViewById(R.id.historyTitle);
        if (elderName != null) title.setText(elderName + "'s History");

        recyclerView = findViewById(R.id.historyRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new HistoryAdapter(messages);
        recyclerView.setAdapter(adapter);

        loadHistory();
    }

    private void loadHistory() {
        if (elderUid == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(elderUid)
                .collection("conversations")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    messages.clear();
                    for (com.google.firebase.firestore.DocumentSnapshot doc : queryDocumentSnapshots) {
                        messages.add(doc.getData());
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private static class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
        private List<Map<String, Object>> list;
        private SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault());

        public HistoryAdapter(List<Map<String, Object>> list) { this.list = list; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Map<String, Object> m = list.get(position);
            String user = (String) m.get("user");
            String ai = (String) m.get("ai");
            long ts = (long) m.get("timestamp");

            holder.text1.setText("You: " + user + "\nAI: " + ai);
            holder.text2.setText(sdf.format(new Date(ts)));
            holder.text1.setTextColor(0xFF1D1D1D);
            holder.text2.setTextColor(0xFF6B6B6B);
        }

        @Override
        public int getItemCount() { return list.size(); }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView text1, text2;
            public ViewHolder(View v) {
                super(v);
                text1 = v.findViewById(android.R.id.text1);
                text2 = v.findViewById(android.R.id.text2);
            }
        }
    }
}
