package com.example.steadysense;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.example.steadysense.models.User;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        new Handler().postDelayed(this::checkAuthStatus, 2000);
    }

    private void checkAuthStatus() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            db.collection("users").document(currentUser.getUid()).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            try {
                                User user = documentSnapshot.toObject(User.class);
                                if (user != null && user.getRole() != null) {
                                    if ("Elder".equals(user.getRole())) {
                                        startActivity(new Intent(MainActivity.this, ElderActivity.class));
                                    } else {
                                        startActivity(new Intent(MainActivity.this, CaretakerActivity.class));
                                    }
                                    finish();
                                } else {
                                    redirectToLogin();
                                }
                            } catch (Exception e) {
                                android.util.Log.e("MainActivity", "Error parsing user object during auto-login", e);
                                redirectToLogin();
                            }
                        } else {
                            redirectToLogin();
                        }
                    })
                    .addOnFailureListener(e -> {
                        android.util.Log.e("MainActivity", "Firestore error during auto-login", e);
                        redirectToLogin();
                    });
        } else {
            redirectToLogin();
        }
    }

    private void redirectToLogin() {
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finish();
    }
}