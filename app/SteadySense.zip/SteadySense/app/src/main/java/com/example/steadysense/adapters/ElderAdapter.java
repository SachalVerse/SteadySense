package com.example.steadysense.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.steadysense.R;
import com.example.steadysense.models.User;
import java.util.List;

public class ElderAdapter extends RecyclerView.Adapter<ElderAdapter.ElderViewHolder> {

    private List<User> elderList;

    public ElderAdapter(List<User> elderList) {
        this.elderList = elderList;
    }

    @NonNull
    @Override
    public ElderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_elder_health, parent, false);
        return new ElderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ElderViewHolder holder, int position) {
        User elder = elderList.get(position);
        holder.nameText.setText(elder.getName());
        
        // Use default values if health data isn't synced yet
        holder.activityText.setText(elder.getLastActivity() != null ? elder.getLastActivity() : "Monitored");
        holder.stepsText.setText(String.valueOf(elder.getStepCount()));
        holder.safetyStatus.setText("PROTECTED");
        
        holder.aiSummaryText.setText("Last checked: Just now. Safety monitoring is active and stable.");

        holder.historyButton.setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(v.getContext(), com.example.steadysense.VoiceHistoryActivity.class);
            intent.putExtra("elderUid", elder.getUserId());
            intent.putExtra("elderName", elder.getName());
            v.getContext().startActivity(intent);
        });

        // Set Map click listener
        holder.viewMapButton.setOnClickListener(v -> {
            String location = elder.getLastKnownLocation();
            double elderLat = 0.0;
            double elderLng = 0.0;
            if (location != null && location.contains("query=")) {
                try {
                    String query = location.substring(location.indexOf("query=") + 6);
                    if (query.contains("&")) {
                        query = query.substring(0, query.indexOf("&"));
                    }
                    String[] parts = query.split(",");
                    elderLat = Double.parseDouble(parts[0]);
                    elderLng = Double.parseDouble(parts[1]);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (elderLat == 0.0 || elderLng == 0.0) {
                // Default fallback to Islamabad if there is no sync location yet
                elderLat = 33.6844;
                elderLng = 73.0479;
            }

            android.content.Intent intent = new android.content.Intent(v.getContext(), com.example.steadysense.MapActivity.class);
            intent.putExtra("elderLat", elderLat);
            intent.putExtra("elderLng", elderLng);
            intent.putExtra("elderName", elder.getName());
            v.getContext().startActivity(intent);
        });

        // Set Timer click listener
        holder.setTimerButton.setOnClickListener(v -> {
            String[] options = {"10 Seconds (Fast Alert)", "15 Seconds (Standard)", "20 Seconds", "30 Seconds", "45 Seconds", "60 Seconds"};
            int[] seconds = {10, 15, 20, 30, 45, 60};
            
            // Determine currently selected index
            int checkedItemIndex = 1; // Default 15s (index 1)
            int currentDuration = elder.getAlertTimerDuration();
            for (int i = 0; i < seconds.length; i++) {
                if (seconds[i] == currentDuration) {
                    checkedItemIndex = i;
                    break;
                }
            }

            final int[] tempSelected = {checkedItemIndex};
            
            new com.google.android.material.dialog.MaterialAlertDialogBuilder(v.getContext())
                .setTitle("Configure Fall Alert Countdown")
                .setSingleChoiceItems(options, checkedItemIndex, (dialog, which) -> {
                    tempSelected[0] = which;
                })
                .setPositiveButton("Save Settings", (dialog, which) -> {
                    int selectedSeconds = seconds[tempSelected[0]];
                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(elder.getUserId())
                        .update("alertTimerDuration", selectedSeconds)
                        .addOnSuccessListener(aVoid -> {
                            elder.setAlertTimerDuration(selectedSeconds);
                            android.widget.Toast.makeText(v.getContext(), "Fall alert timer set to " + selectedSeconds + "s for " + elder.getName(), android.widget.Toast.LENGTH_LONG).show();
                        })
                        .addOnFailureListener(e -> {
                            android.widget.Toast.makeText(v.getContext(), "Failed to update timer: " + e.getLocalizedMessage(), android.widget.Toast.LENGTH_LONG).show();
                        });
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    @Override
    public int getItemCount() {
        return elderList.size();
    }

    static class ElderViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, activityText, stepsText, safetyStatus, aiSummaryText;
        View historyButton, viewMapButton, setTimerButton;

        public ElderViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.elderNameText);
            activityText = itemView.findViewById(R.id.activityText);
            stepsText = itemView.findViewById(R.id.stepsText);
            safetyStatus = itemView.findViewById(R.id.safetyStatus);
            aiSummaryText = itemView.findViewById(R.id.aiSummaryText);
            historyButton = itemView.findViewById(R.id.viewHistoryButton);
            viewMapButton = itemView.findViewById(R.id.viewMapButton);
            setTimerButton = itemView.findViewById(R.id.setTimerButton);
        }
    }
}
