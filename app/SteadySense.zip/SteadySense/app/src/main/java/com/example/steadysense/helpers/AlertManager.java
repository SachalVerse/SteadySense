package com.example.steadysense.helpers;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.example.steadysense.models.User;

import java.util.HashMap;
import java.util.Map;

public class AlertManager {

    private final Context context;
    private final FirebaseFirestore db;
    private final FirebaseAuth mAuth;
    private final LocationHelper locationHelper;

    public AlertManager(Context context) {
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
        this.mAuth = FirebaseAuth.getInstance();
        this.locationHelper = new LocationHelper(context);
    }

    public void triggerEmergency(String type) {
        String uid = mAuth.getCurrentUser().getUid();
        
        locationHelper.getCurrentLocation(locationLink -> {
            db.collection("users").document(uid).get().addOnSuccessListener(documentSnapshot -> {
                User elder = documentSnapshot.toObject(User.class);
                if (elder != null) {
                    saveEventToCloud(elder, type, locationLink);
                }
            });
        });
    }

    private void saveEventToCloud(User elder, String type, String locationLink) {
        java.util.List<String> cIds = elder.getCaretakerIds();
        if (cIds == null || cIds.isEmpty()) {
            cIds = new java.util.ArrayList<>();
            if (elder.getCaretakerId() != null && !elder.getCaretakerId().isEmpty()) {
                cIds.add(elder.getCaretakerId());
            }
        }

        if (cIds.isEmpty()) {
            Log.e("AlertManager", "No Caretakers linked. Cannot trigger alerts.");
            Toast.makeText(context, "No Caretakers linked!", Toast.LENGTH_LONG).show();
            return;
        }

        for (String cId : cIds) {
            final String currentCId = cId;
            Map<String, Object> event = new HashMap<>();
            event.put("elderId", elder.getUserId());
            event.put("elderName", elder.getName());
            event.put("caretakerId", currentCId);
            event.put("type", type);
            event.put("timestamp", System.currentTimeMillis());
            event.put("location", locationLink);
            event.put("status", "ACTIVE");

            db.collection("events").add(event)
                    .addOnSuccessListener(documentReference -> {
                        Log.d("AlertManager", "Emergency logged in Firestore for Caretaker: " + currentCId);
                        Toast.makeText(context, "Alert sent to Caretaker!", Toast.LENGTH_SHORT).show();
                        
                        sendSimulatedEmailForCaretakerId(currentCId, elder, type, locationLink);
                    })
                    .addOnFailureListener(e -> {
                        Log.e("AlertManager", "Failed to log emergency for Caretaker: " + currentCId, e);
                    });
        }
    }

    private void sendSimulatedEmailForCaretakerId(String cId, User elder, String type, String locationLink) {
        if (cId == null || cId.isEmpty()) {
            Log.e("AlertManager", "No Caretaker ID. Cannot send email.");
            return;
        }

        if (android.util.Patterns.EMAIL_ADDRESS.matcher(cId).matches()) {
            executeDirectEmail(cId, elder, type, locationLink);
            return;
        }

        String cleanId = cId.replace("#", "").toUpperCase();
        db.collection("users")
                .whereEqualTo("role", "Caretaker")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (com.google.firebase.firestore.DocumentSnapshot doc : queryDocumentSnapshots) {
                        String uid = doc.getId();
                        String resolvedId = uid.substring(0, 6).toUpperCase();
                        if (resolvedId.equals(cleanId)) {
                            String email = doc.getString("email");
                            if (email != null) {
                                executeDirectEmail(email, elder, type, locationLink);
                                return;
                            }
                        }
                    }
                    Log.e("AlertManager", "Could not resolve caretaker email for ID: " + cId);
                });
    }

    private void executeDirectEmail(String recipient, User elder, String type, String locationLink) {
        String emailSubject = "EMERGENCY ALERT: " + type + " for " + elder.getName();
        String emailContent = "Subject: EMERGENCY ALERT - " + type + "\n" +
                "Elder Name: " + elder.getName() + "\n" +
                "Type: " + type + "\n" +
                "Location: " + locationLink + "\n" +
                "This is an automated emergency message from SteadySense.";

        EmailHelper.sendEmailDirect(recipient, emailSubject, emailContent);
        Log.d("AlertManager", "DIRECT EMAIL SENT TO RESOLVED EMAIL: " + recipient);
    }
}
