package com.example.steadysense;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import com.example.steadysense.helpers.LocaleHelper;

public class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }
}
