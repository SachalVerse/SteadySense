package com.example.steadysense.helpers;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class GeminiHelper {

    private static final String API_KEY = "YOUR_API_KEY_HERE";
    private final GenerativeModelFutures model;
    private final Executor executor;
    
    public GeminiHelper() {
        GenerativeModel gm = new GenerativeModel("gemini-1.5-flash", API_KEY);
        this.model = GenerativeModelFutures.from(gm);
        this.executor = Executors.newSingleThreadExecutor();
    }

    public interface GeminiResponseCallback {
        void onSuccess(String response);
        void onFailure(Throwable t);
    }

    public void getAiResponse(String prompt, String context, GeminiResponseCallback callback) {
        String systemInstruction = "You are 'Aidi', a warm, empathetic, and highly proactive AI healthcare companion for the elderly. " +
                "CONVERSATIONAL STYLE: Speak like a caring friend. Avoid clinical or script-like language. " +
                "STRICT SCOPE: Assist ONLY with elderly health, wellness, and safety. If the user asks about anything irrelevant (politics, general facts, jokes, or random questions), politely say: 'I'm sorry, I'm only here to help with your health and safety. Let's focus on that.' " +
                "PROACTIVE HEALTH LOGIC: If a user mentions a symptom: " +
                "1. Ask follow-up questions to understand the severity. " +
                "2. Provide immediate safety advice (sit down, drink water). " +
                "3. If statement is unclear, ask for clarification. " +
                "LANGUAGE MIRRORING: You MUST respond in the SAME language the user used. If the user speaks in URDU, you MUST respond in URDU. If they speak in English, respond in English. " +
                "Keep responses warm, simple, and relevant to the user's condition.";

        if (context != null && !context.isEmpty()) {
            systemInstruction += "\n[RECENT CONTEXT: " + context + "]\n";
        }

        Content content = new Content.Builder()
                .addText(systemInstruction + "User query: " + prompt)
                .build();

        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);
        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                callback.onSuccess(result.getText());
            }

            @Override
            public void onFailure(Throwable t) {
                callback.onFailure(t);
            }
        }, executor);
    }
    
    public void predictRisk(float accelerationMagnitude, GeminiResponseCallback callback) {
        String prompt = "Based on accelerometer data, a sudden impact of " + accelerationMagnitude + " m/s^2 was detected. " +
                "Is this considered a high-risk fall for an elderly person? Answer with 'Risk: High' or 'Risk: Low' and a brief explanation.";
        getAiResponse(prompt, null, callback);
    }
}
