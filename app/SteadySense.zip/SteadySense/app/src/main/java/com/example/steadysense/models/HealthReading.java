package com.example.steadysense.models;

public class HealthReading {
    private long timestamp;
    private int steps;
    private String activityType; // Walking, Sitting, Lying, etc.
    private double accelerometerMagnitude;
    private boolean isSafe;

    public HealthReading() {}

    public HealthReading(long timestamp, int steps, String activityType, double accelerometerMagnitude, boolean isSafe) {
        this.timestamp = timestamp;
        this.steps = steps;
        this.activityType = activityType;
        this.accelerometerMagnitude = accelerometerMagnitude;
        this.isSafe = isSafe;
    }

    // Getters and Setters
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public int getSteps() { return steps; }
    public void setSteps(int steps) { this.steps = steps; }
    public String getActivityType() { return activityType; }
    public void setActivityType(String activityType) { this.activityType = activityType; }
    public double getAccelerometerMagnitude() { return accelerometerMagnitude; }
    public void setAccelerometerMagnitude(double accelerometerMagnitude) { this.accelerometerMagnitude = accelerometerMagnitude; }
    public boolean isSafe() { return isSafe; }
    public void setSafe(boolean safe) { isSafe = safe; }
}
