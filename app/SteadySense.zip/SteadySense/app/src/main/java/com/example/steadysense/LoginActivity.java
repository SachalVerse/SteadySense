package com.example.steadysense;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.example.steadysense.models.User;
import com.example.steadysense.helpers.LocaleHelper;

public class LoginActivity extends BaseActivity {

    private TextInputEditText emailEditText, passwordEditText;
    private MaterialButton loginButton, langButton;
    private TextView registerText, forgotPasswordText;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        langButton = findViewById(R.id.langButton);
        registerText = findViewById(R.id.registerText);
        forgotPasswordText = findViewById(R.id.forgotPasswordText);
        progressBar = findViewById(R.id.progressBar);

        langButton.setOnClickListener(v -> toggleLanguage());
        
        forgotPasswordText.setOnClickListener(v -> {
            ForgotPasswordFragment fragment = new ForgotPasswordFragment();
            fragment.show(getSupportFragmentManager(), "ForgotPassword");
        });

        loginButton.setOnClickListener(v -> loginUser());
        registerText.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void toggleLanguage() {
        String currentLang = LocaleHelper.getLanguage(this);
        String newLang = currentLang.equals("ur") ? "en" : "ur";
        LocaleHelper.setLocale(this, newLang);
        recreate();
    }

    private void loginUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        checkUserRole();
                    } else {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void checkUserRole() {
        if (mAuth.getCurrentUser() == null) {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String uid = mAuth.getCurrentUser().getUid();
        db.collection("users").document(uid).get()
                .addOnSuccessListener(documentSnapshot -> {
                    progressBar.setVisibility(View.GONE);
                    if (documentSnapshot.exists()) {
                        try {
                            User user = documentSnapshot.toObject(User.class);
                            if (user != null && user.getRole() != null) {
                                if ("Elder".equals(user.getRole())) {
                                    startActivity(new Intent(LoginActivity.this, ElderActivity.class));
                                } else {
                                    startActivity(new Intent(LoginActivity.this, CaretakerActivity.class));
                                }
                                finish();
                            } else {
                                Toast.makeText(this, "User profile is incomplete. Please contact support.", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            android.util.Log.e("LoginActivity", "Error parsing user object", e);
                            Toast.makeText(this, "Error loading profile data.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(this, "User profile not found in database.", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Failed to fetch user role: " + e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    android.util.Log.e("LoginActivity", "Firestore error", e);
                });
    }
}
