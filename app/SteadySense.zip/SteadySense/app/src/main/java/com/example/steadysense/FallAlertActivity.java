package com.example.steadysense;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.example.steadysense.models.User;
import java.util.HashMap;
import java.util.Map;

public class FallAlertActivity extends BaseActivity {

    private TextView countdownText;
    private MaterialButton okButton;
    private CountDownTimer countDownTimer;
    private Ringtone ringtone;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fall_alert);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        countdownText = findViewById(R.id.countdownText);
        okButton = findViewById(R.id.iAmOkayButton);

        fetchUserAgeAndStartTimer();

        // Play alarm sound safely with fallbacks
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (notification == null) {
            notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        }
        if (notification != null) {
            ringtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
            if (ringtone != null) {
                ringtone.play();
            }
        }

        okButton.setOnClickListener(v -> {
            if (countDownTimer != null) countDownTimer.cancel();
            if (ringtone != null) ringtone.stop();
            Toast.makeText(this, "Alert Cancelled", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void fetchUserAgeAndStartTimer() {
        String uid = mAuth.getUid();
        if (uid == null) {
            startTimer(15000); // Default 15s
            return;
        }

        db.collection("users").document(uid).get().addOnSuccessListener(documentSnapshot -> {
            long duration = 15000; // Default fallback
            if (documentSnapshot.exists()) {
                Long customDuration = documentSnapshot.getLong("alertTimerDuration");
                if (customDuration != null && customDuration > 0) {
                    duration = customDuration * 1000; // Custom duration in milliseconds
                } else {
                    int age = 0;
                    Long ageLong = documentSnapshot.getLong("age");
                    if (ageLong != null) age = ageLong.intValue();

                    if (age > 80) {
                        duration = 10000; // 10s for very elderly (fast alert)
                    } else if (age > 60) {
                        duration = 15000; // 15s standard
                    } else {
                        duration = 20000; // 20s for younger/more mobile
                    }
                }
            }
            startTimer(duration);
        }).addOnFailureListener(e -> {
            startTimer(15000); // Fallback
        });
    }

    private void startTimer(long durationMillis) {
        if (countDownTimer != null) countDownTimer.cancel();
        
        countDownTimer = new CountDownTimer(durationMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                countdownText.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                sendAlertToCaretaker();
            }
        }.start();
    }

    private void sendAlertToCaretaker() {
        if (ringtone != null && ringtone.isPlaying()) {
            ringtone.stop();
        }
        
        com.example.steadysense.helpers.AlertManager alertManager = new com.example.steadysense.helpers.AlertManager(this);
        alertManager.triggerEmergency("FALL_DETECTED");
        
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
        if (ringtone != null) ringtone.stop();
    }
}
